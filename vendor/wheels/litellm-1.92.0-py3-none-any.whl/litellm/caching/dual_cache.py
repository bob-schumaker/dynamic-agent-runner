"""
Dual Cache implementation - Class to update both Redis and an in-memory cache simultaneously.

Has 4 primary methods:
    - set_cache
    - get_cache
    - async_set_cache
    - async_get_cache
"""

import asyncio
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from threading import Lock
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Union

if TYPE_CHECKING:
    from litellm.types.caching import RedisPipelineIncrementOperation

import litellm
from litellm._logging import print_verbose, verbose_logger
from litellm.constants import DEFAULT_MAX_REDIS_BATCH_CACHE_SIZE

from .base_cache import BaseCache
from .in_memory_cache import InMemoryCache
from .redis_cache import RedisCache

if TYPE_CHECKING:
    from opentelemetry.trace import Span as _Span

    Span = Union[_Span, Any]
else:
    Span = Any

from collections import OrderedDict


class LimitedSizeOrderedDict(OrderedDict):
    def __init__(self, *args, max_size=100, **kwargs):
        super().__init__(*args, **kwargs)
        self.max_size = max_size

    def __setitem__(self, key, value):
        # If inserting a new key exceeds max size, remove the oldest item
        if len(self) >= self.max_size:
            self.popitem(last=False)
        super().__setitem__(key, value)


class DualCache(BaseCache):
    """
    DualCache is a cache implementation that updates both Redis and an in-memory cache simultaneously.
    When data is updated or inserted, it is written to both the in-memory cache + Redis.
    This ensures that even if Redis hasn't been updated yet, the in-memory cache reflects the most recent data.
    """

    def __init__(
        self,
        in_memory_cache: Optional[InMemoryCache] = None,
        redis_cache: Optional[RedisCache] = None,
        default_in_memory_ttl: Optional[float] = None,
        default_redis_ttl: Optional[float] = None,
        default_redis_batch_cache_expiry: Optional[float] = None,
        default_max_redis_batch_cache_size: int = DEFAULT_MAX_REDIS_BATCH_CACHE_SIZE,
    ) -> None:
        super().__init__()
        # If in_memory_cache is not provided, use the default InMemoryCache
        self.in_memory_cache = in_memory_cache or InMemoryCache()
        # If redis_cache is not provided, use the default RedisCache
        self.redis_cache = redis_cache
        self.last_redis_batch_access_time = LimitedSizeOrderedDict(max_size=default_max_redis_batch_cache_size)
        self._last_redis_batch_access_time_lock = Lock()
        self.redis_batch_cache_expiry = (
            default_redis_batch_cache_expiry or litellm.default_redis_batch_cache_expiry or 10
        )
        self.default_in_memory_ttl = default_in_memory_ttl or litellm.default_in_memory_ttl
        self.default_redis_ttl = default_redis_ttl or litellm.default_redis_ttl

    def update_cache_ttl(self, default_in_memory_ttl: Optional[float], default_redis_ttl: Optional[float]):
        if default_in_memory_ttl is not None:
            self.default_in_memory_ttl = default_in_memory_ttl

        if default_redis_ttl is not None:
            self.default_redis_ttl = default_redis_ttl

    def attach_redis_cache(
        self,
        redis_cache: Optional[RedisCache] = None,
        *,
        default_redis_ttl: Optional[float] = None,
    ) -> None:
        """
        Attach a Redis backend if this DualCache does not already have one.

        No-op when ``redis_cache`` is None or when Redis was already set (constructor
        or a prior attach). Use this for lazy wiring after a shared Redis client exists.
        Does not backfill in-memory-only keys to Redis.
        """
        if redis_cache is None or self.redis_cache is not None:
            return
        self.redis_cache = redis_cache
        if default_redis_ttl is not None:
            self.default_redis_ttl = default_redis_ttl

    def set_cache(self, key, value, local_only: bool = False, **kwargs):
        # Update both Redis and in-memory cache
        try:
            if self.in_memory_cache is not None:
                if "ttl" not in kwargs and self.default_in_memory_ttl is not None:
                    kwargs["ttl"] = self.default_in_memory_ttl

                self.in_memory_cache.set_cache(key, value, **kwargs)

            if self.redis_cache is not None and local_only is False:
                self.redis_cache.set_cache(key, value, **kwargs)
        except Exception as e:
            print_verbose(e)

    def increment_cache(self, key, value: int, local_only: bool = False, **kwargs) -> int:
        """
        Key - the key in cache

        Value - int - the value you want to increment by

        Returns - int - the incremented value
        """
        try:
            result: int = value
            if self.in_memory_cache is not None:
                result = self.in_memory_cache.increment_cache(key, value, **kwargs)

            if self.redis_cache is not None and local_only is False:
                result = self.redis_cache.increment_cache(key, value, **kwargs)

            return result
        except Exception as e:
            verbose_logger.error(f"LiteLLM Cache: Excepton async add_cache: {str(e)}")
            raise e

    def get_cache(
        self,
        key,
        parent_otel_span: Optional[Span] = None,
        local_only: bool = False,
        **kwargs,
    ):
        # Try to fetch from in-memory cache first
        try:
            result = None
            if self.in_memory_cache is not None:
                in_memory_result = self.in_memory_cache.get_cache(key, **kwargs)

                if in_memory_result is not None:
                    result = in_memory_result

            if result is None and self.redis_cache is not None and local_only is False:
                # If not found in in-memory cache, try fetching from Redis
                redis_result = self.redis_cache.get_cache(key, parent_otel_span=parent_otel_span)

                if redis_result is not None:
                    # Update in-memory cache with the value from Redis
                    self.in_memory_cache.set_cache(key, redis_result, **kwargs)

                result = redis_result

            print_verbose(f"get cache: cache result: {result}")
            return result
        except Exception:
            verbose_logger.error(traceback.format_exc())

    def batch_get_cache(
        self,
        keys: list,
        parent_otel_span: Optional[Span] = None,
        local_only: bool = False,
        **kwargs,
    ):
        received_args = locals()
        received_args.pop("self")

        def run_in_new_loop():
            """Run the coroutine in a new event loop within this thread."""
            new_loop = asyncio.new_event_loop()
            try:
                asyncio.set_event_loop(new_loop)
                return new_loop.run_until_complete(self.async_batch_get_cache(**received_args))
            finally:
                new_loop.close()
                asyncio.set_event_loop(None)

        try:
            # First, try to get the current event loop
            _ = asyncio.get_running_loop()
            # If we're already in an event loop, run in a separate thread
            # to avoid nested event loop issues
            with ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(run_in_new_loop)
                return future.result()

        except RuntimeError:
            # No running event loop, we can safely run in this thread
            return run_in_new_loop()

    async def async_get_cache(
        self,
        key,
        parent_otel_span: Optional[Span] = None,
        local_only: bool = False,
        **kwargs,
    ):
        # Try to fetch from in-memory cache first
        try:
            print_verbose(f"async get cache: cache key: {key}; local_only: {local_only}")
            result = None
            if self.in_memory_cache is not None:
                in_memory_result = await self.in_memory_cache.async_get_cache(key, **kwargs)

                print_verbose(f"in_memory_result: {in_memory_result}")
                if in_memory_result is not None:
                    result = in_memory_result

            if result is None and self.redis_cache is not None and local_only is False:
                # If not found in in-memory cache, try fetching from Redis
                redis_result = await self.redis_cache.async_get_cache(key, parent_otel_span=parent_otel_span)

                if redis_result is not None:
                    # Update in-memory cache with the value from Redis
                    await self.in_memory_cache.async_set_cache(key, redis_result, **kwargs)

                result = redis_result

            print_verbose(f"get cache: cache result: {result}")
            return result
        except Exception:
            verbose_logger.error(traceback.format_exc())

    def _reserve_redis_batch_keys(
        self,
        current_time: float,
        keys: List[str],
        result: List[Any],
    ) -> Tuple[List[str], Dict[str, Optional[float]]]:
        """
        Atomically choose keys to fetch from Redis and reserve their access time.
        This prevents check-then-act races under concurrent async callers.
        """
        sublist_keys: List[str] = []
        previous_access_times: Dict[str, Optional[float]] = {}

        with self._last_redis_batch_access_time_lock:
            for key, value in zip(keys, result):
                if value is not None:
                    continue

                if (
                    key not in self.last_redis_batch_access_time
                    or current_time - self.last_redis_batch_access_time[key] >= self.redis_batch_cache_expiry
                ):
                    sublist_keys.append(key)
                    previous_access_times[key] = self.last_redis_batch_access_time.get(key)
                    self.last_redis_batch_access_time[key] = current_time

        return sublist_keys, previous_access_times

    def _rollback_redis_batch_key_reservations(self, previous_access_times: Dict[str, Optional[float]]) -> None:
        with self._last_redis_batch_access_time_lock:
            for key, previous_time in previous_access_times.items():
                if previous_time is None:
                    self.last_redis_batch_access_time.pop(key, None)
                else:
                    self.last_redis_batch_access_time[key] = previous_time

    async def async_batch_get_cache(
        self,
        keys: list,
        parent_otel_span: Optional[Span] = None,
        local_only: bool = False,
        **kwargs,
    ):
        try:
            result = [None] * len(keys)
            if self.in_memory_cache is not None:
                in_memory_result = await self.in_memory_cache.async_batch_get_cache(keys, **kwargs)

                if in_memory_result is not None:
                    result = in_memory_result

            if None in result and self.redis_cache is not None and local_only is False:
                """
                - for the none values in the result
                - check the redis cache
                """
                current_time = time.time()
                sublist_keys, previous_access_times = self._reserve_redis_batch_keys(current_time, keys, result)

                # Only hit Redis if enough time has passed since last access.
                if len(sublist_keys) > 0:
                    try:
                        # If not found in in-memory cache, try fetching from Redis
                        redis_result = await self.redis_cache.async_batch_get_cache(
                            sublist_keys, parent_otel_span=parent_otel_span
                        )
                    except Exception:
                        # Do not throttle subsequent callers if the Redis read fails.
                        self._rollback_redis_batch_key_reservations(previous_access_times)
                        raise

                    # Short-circuit if redis_result is None or contains only None values
                    if redis_result is None or all(v is None for v in redis_result.values()):
                        return result

                    # Pre-compute key-to-index mapping for O(1) lookup
                    key_to_index = {key: i for i, key in enumerate(keys)}

                    # Update both result and in-memory cache in a single loop
                    for key, value in redis_result.items():
                        result[key_to_index[key]] = value

                        if value is not None and self.in_memory_cache is not None:
                            await self.in_memory_cache.async_set_cache(key, value, **kwargs)

            return result
        except Exception:
            verbose_logger.error(traceback.format_exc())

    async def async_set_cache(self, key, value, local_only: bool = False, **kwargs):
        print_verbose(f"async set cache: cache key: {key}; local_only: {local_only}; value: {value}")
        try:
            if self.in_memory_cache is not None:
                if "ttl" not in kwargs and self.default_in_memory_ttl is not None:
                    kwargs["ttl"] = self.default_in_memory_ttl
                await self.in_memory_cache.async_set_cache(key, value, **kwargs)

            if self.redis_cache is not None and local_only is False:
                await self.redis_cache.async_set_cache(key, value, **kwargs)
        except Exception as e:
            verbose_logger.exception(f"LiteLLM Cache: Excepton async add_cache: {str(e)}")

    # async_batch_set_cache
    async def async_set_cache_pipeline(self, cache_list: list, local_only: bool = False, **kwargs):
        """
        Batch write values to the cache
        """
        print_verbose(f"async batch set cache: cache keys: {cache_list}; local_only: {local_only}")
        try:
            if self.in_memory_cache is not None:
                if "ttl" not in kwargs and self.default_in_memory_ttl is not None:
                    kwargs["ttl"] = self.default_in_memory_ttl
                await self.in_memory_cache.async_set_cache_pipeline(cache_list=cache_list, **kwargs)

            if self.redis_cache is not None and local_only is False:
                await self.redis_cache.async_set_cache_pipeline(
                    cache_list=cache_list, ttl=kwargs.pop("ttl", None), **kwargs
                )
        except Exception as e:
            verbose_logger.exception(f"LiteLLM Cache: Excepton async add_cache: {str(e)}")

    async def async_increment_cache(
        self,
        key,
        value: float,
        parent_otel_span: Optional[Span] = None,
        local_only: bool = False,
        refresh_ttl: bool = False,
        **kwargs,
    ) -> Optional[float]:
        """
        Key - the key in cache

        Value - float - the value you want to increment by

        Refresh_ttl - bool - if True, resets the Redis TTL on every write.
        Default False preserves window-style semantics.

        Returns - the incremented value, or None if no cache backend is
        available (in_memory_cache is None and Redis failed/is absent).
        """
        result: Optional[float] = None
        try:
            if self.in_memory_cache is not None:
                result = await self.in_memory_cache.async_increment(key, value, **kwargs)

            if self.redis_cache is not None and local_only is False:
                result = await self.redis_cache.async_increment(
                    key,
                    value,
                    parent_otel_span=parent_otel_span,
                    ttl=kwargs.get("ttl", None),
                    refresh_ttl=refresh_ttl,
                )

            return result
        except Exception as e:
            verbose_logger.warning(
                "Redis async_increment_cache failed, falling back to in-memory result: %s",
                e,
            )
            return result

    async def async_increment_cache_pipeline(
        self,
        increment_list: List["RedisPipelineIncrementOperation"],
        local_only: bool = False,
        parent_otel_span: Optional[Span] = None,
        **kwargs,
    ) -> Optional[List[float]]:
        result: Optional[List[float]] = None
        try:
            if self.in_memory_cache is not None:
                result = await self.in_memory_cache.async_increment_pipeline(
                    increment_list=increment_list,
                    parent_otel_span=parent_otel_span,
                )

            if self.redis_cache is not None and local_only is False:
                result = await self.redis_cache.async_increment_pipeline(
                    increment_list=increment_list,
                    parent_otel_span=parent_otel_span,
                )

            return result
        except Exception as e:
            verbose_logger.warning(
                "Redis async_increment_cache_pipeline failed, falling back to in-memory result: %s",
                e,
            )
            return result

    async def async_set_cache_sadd(self, key, value: List, local_only: bool = False, **kwargs) -> None:
        """
        Add value to a set

        Key - the key in cache

        Value - str - the value you want to add to the set

        Returns - None
        """
        try:
            if self.in_memory_cache is not None:
                _ = await self.in_memory_cache.async_set_cache_sadd(key, value, ttl=kwargs.get("ttl", None))

            if self.redis_cache is not None and local_only is False:
                _ = await self.redis_cache.async_set_cache_sadd(key, value, ttl=kwargs.get("ttl", None))

            return None
        except Exception as e:
            raise e  # don't log, if exception is raised

    def flush_cache(self):
        if self.in_memory_cache is not None:
            self.in_memory_cache.flush_cache()
        if self.redis_cache is not None:
            self.redis_cache.flush_cache()

    def delete_cache(self, key):
        """
        Delete a key from the cache
        """
        if self.in_memory_cache is not None:
            self.in_memory_cache.delete_cache(key)
        if self.redis_cache is not None:
            self.redis_cache.delete_cache(key)

    async def async_delete_cache(self, key: str):
        """
        Delete a key from the cache
        """
        if self.in_memory_cache is not None:
            self.in_memory_cache.delete_cache(key)
        if self.redis_cache is not None:
            await self.redis_cache.async_delete_cache(key)

    async def async_get_ttl(self, key: str) -> Optional[int]:
        """
        Get the remaining TTL of a key in in-memory cache or redis
        """
        ttl = await self.in_memory_cache.async_get_ttl(key)
        if ttl is None and self.redis_cache is not None:
            ttl = await self.redis_cache.async_get_ttl(key)
        return ttl
